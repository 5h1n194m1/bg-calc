<?php

use App\Livewire\Tournament\Index;
use Illuminate\Support\Facades\Route;

Route::prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::redirect('/', '/admin/tournaments');

        Route::get('/tournaments', Index::class)
            ->name('tournaments.index');

    });